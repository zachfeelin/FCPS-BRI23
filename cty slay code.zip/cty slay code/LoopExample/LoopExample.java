public class LoopExample
{
   public static void main(String[] args)
   {
      //goto 11
      
      //int x = 3
      //System.out.println(x);
      //
      //
      //-----------------------------------------------------
      //
      //
      //FOR   initialization      condition       iteration
      for(int i = 1;              i<=10;          i++){
         //body of the loop
         System.out.println("Hi!" + i);
      }
      //WHILE
      while(true){
         System.out.println("uwu");
      }
   }
}