public class Output
{
   public static void main(String[] args)
   {
      System.out.println(3 + 4 - 94584 * 4 / 2);
     
   }
}