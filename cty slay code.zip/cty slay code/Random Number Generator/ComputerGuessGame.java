import java.util.Random;
import java.util.Scanner;
public class ComputerGuessGame
{
   public static void main (String[] args)
   {
      Random rng = new Random();
      Scanner in = new Scanner(System.in);
      System.out.println("Hello! I am *number guesser*.");
      System.out.println("Please pick a number between 1 - 10 (DON'T TELL ME) and press \"enter\" when you do");
      in.nextLine();
      int compgot = 0;
      while(compgot == 0){
      }
   }
}