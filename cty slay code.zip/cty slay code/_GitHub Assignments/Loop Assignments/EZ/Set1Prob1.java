public class Set1Prob1
{
   public static void main (String[] args)
   {
      for(int i=0; i<=80; i++){
         if(i%2==0){
         System.out.println(i);
         }
         else{
         i++;
         System.out.println(i);
         }
      }
   }
}