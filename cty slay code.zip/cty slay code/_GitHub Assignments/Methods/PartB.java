//Static, With Arguments
public class PartB {
    public static void main(String[] args){

    }
    
}
